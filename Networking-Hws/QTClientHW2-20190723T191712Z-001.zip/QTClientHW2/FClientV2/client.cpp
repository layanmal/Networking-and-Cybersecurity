#include "client.h"
#include "ui_client.h"
#include <QFileDialog>
#include<iostream>
#include<QFileDialog>

Client::Client(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Client)
{
    ui->setupUi(this);


        msgBox.setParent(this);
        msgBox.setWindowTitle("File Recived");
        msgBox.setStandardButtons(QMessageBox::Save);
        msgBox.addButton(QMessageBox::Discard);
        msgBox.setDefaultButton(QMessageBox::No);
        msgBox.setWindowModality(Qt::NonModal);
isFile=false;
isMsg=false;
        this->clientSocket = new QTcpSocket();
        ABQofFiles = new QByteArray[100];

}

Client::~Client()
{
    delete ui;

}




void Client::readData(){

    qDebug() << "reading...";
QString fileName ;
QByteArray  BArray;
  int dlength=clientSocket->bytesAvailable();
BArray =clientSocket->readAll();

qDebug() << BArray;
QString s_data = QString::fromStdString( BArray.toStdString());

if(s_data.contains("filename")){
    s_data.remove(0,2);
    s_data.remove(0,8);
    ui->textEdit_Status->append("SXX : "+s_data);
ui->AvailableFilesListWidget->addItem(s_data);
}
else if(s_data.contains("sendmssgfromserver")){
    s_data.remove(0,2);
     s_data.remove(0,18);
    isMsg=true;
    isFile=false;
    ui->textEdit_Conversation->append("Server : "+s_data);
}else {
    //if(s_data.contains("sendfilefromserver")){

//BArray.remove(0,2);
//BArray.remove(0,18);

    static int fn =0;
      QString fileName = "file"+QString::number(fn)+"";

          ABQofFiles[fn]=BArray;
          ui->textEdit_Status->append("Receiving : "+QString::number(dlength)+" Bytes ...");
    //   if(dlength<1024) {
          QList<QListWidgetItem*> selectedFiles  =  ui->AvailableFilesListWidget->selectedItems();


          for(int i=0;i<selectedFiles.size();i++){

        QFile savedFile(file_name);
        if (!savedFile.open(QFile::Append))
            {

                    ui->textEdit_Status->append("Error in creating a file to save to !");


           }else{

            savedFile.write(ABQofFiles[fn]);

    }

        }


   //}

    isFile=true;
    isMsg=false;

}

}




void Client::on_pbConnect_clicked()
{
    ui->pbSend->setEnabled(true);
    ui->pbDownload->setEnabled(true);
    ui->pbDisConnect->setEnabled(true);
     ui->pbConnect->setEnabled(false);

   serverIP = QHostAddress(ui->lineEdit_ServerIP->text());

   QString serverPortString = ui->lineEdit_ServerPort->text();
   serverPort = serverPortString.toUShort();

   clientIP = QHostAddress(ui->lineEdit_ClientIP->text());

   QString clientPortString = ui->lineEdit_ClientPort->text();
   clientPort = clientPortString.toUShort();

     connect(clientSocket, SIGNAL(readyRead()),this, SLOT(readData()));

 qDebug() << "connecting...";
         clientSocket->bind(clientIP,clientPort);
        clientSocket->connectToHost(serverIP,serverPort);


       if(!clientSocket->waitForConnected(3000))
       {
           QMessageBox msgBox;
             msgBox.setText("Pls enter the right server !");
             msgBox.exec();

       }else{

           ui->textEdit_Status->append("This client got connected to the server successfully !");


       }
}

void Client::on_pbSend_clicked()
{



           QString s = this->ui->lineEdit_Mssage->text() ;

            QByteArray bufferSent;
            bufferSent.append(s);
            qDebug() <<bufferSent;

            clientSocket->write(bufferSent);
             ui->textEdit_Conversation->append("Me : "+ s );
             qDebug() << "The Message was sent successfully";


}

void Client::on_pbDownload_clicked()
{

    file_name = QFileDialog::getSaveFileName(this,"Downloading the selected file ","C:/Users/ShutDowner007/Downloads");
   QList<QListWidgetItem*> selectedFiles  =  ui->AvailableFilesListWidget->selectedItems();



    for(int i=0;i<selectedFiles.size();i++){


         QByteArray bufferSent;
         bufferSent.append("sendfile"+selectedFiles.at(i)->text());
         qDebug() <<bufferSent;

         clientSocket->write(bufferSent);

}

}


void Client::on_pbDisConnect_clicked()
{
    QString s ="exit(1)";

     QByteArray bufferSent;
     bufferSent.append(s);
     qDebug() <<bufferSent;

     clientSocket->write(bufferSent);
      clientSocket->disconnectFromHost();
      ui->pbSend->setEnabled(false);
      ui->pbDownload->setEnabled(false);
      ui->pbDisConnect->setEnabled(false);
         ui->pbConnect->setEnabled(false);


      qDebug() << "The Client was DisConnected !";
}
