/********************************************************************************
** Form generated from reading UI file 'client.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENT_H
#define UI_CLIENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Client
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *lineEdit_ServerIP;
    QLineEdit *lineEdit_ServerPort;
    QPushButton *pbConnect;
    QLabel *label_3;
    QLineEdit *lineEdit_Mssage;
    QPushButton *pbSend;
    QTextEdit *textEdit_Conversation;
    QLabel *label_4;
    QListWidget *AvailableFilesListWidget;
    QLabel *label_5;
    QPushButton *pbDownload;
    QLineEdit *lineEdit_ClientPort;
    QLabel *label_6;
    QLabel *label_7;
    QLineEdit *lineEdit_ClientIP;
    QPushButton *pbDisConnect;
    QTextEdit *textEdit_Status;
    QLabel *label_8;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *Client)
    {
        if (Client->objectName().isEmpty())
            Client->setObjectName(QStringLiteral("Client"));
        Client->resize(745, 590);
        centralWidget = new QWidget(Client);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(40, 40, 55, 16));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(330, 40, 81, 16));
        lineEdit_ServerIP = new QLineEdit(centralWidget);
        lineEdit_ServerIP->setObjectName(QStringLiteral("lineEdit_ServerIP"));
        lineEdit_ServerIP->setGeometry(QRect(120, 40, 181, 22));
        lineEdit_ServerPort = new QLineEdit(centralWidget);
        lineEdit_ServerPort->setObjectName(QStringLiteral("lineEdit_ServerPort"));
        lineEdit_ServerPort->setGeometry(QRect(420, 40, 71, 22));
        pbConnect = new QPushButton(centralWidget);
        pbConnect->setObjectName(QStringLiteral("pbConnect"));
        pbConnect->setGeometry(QRect(540, 30, 81, 28));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(60, 110, 55, 16));
        lineEdit_Mssage = new QLineEdit(centralWidget);
        lineEdit_Mssage->setObjectName(QStringLiteral("lineEdit_Mssage"));
        lineEdit_Mssage->setGeometry(QRect(140, 110, 351, 22));
        pbSend = new QPushButton(centralWidget);
        pbSend->setObjectName(QStringLiteral("pbSend"));
        pbSend->setGeometry(QRect(540, 110, 81, 28));
        textEdit_Conversation = new QTextEdit(centralWidget);
        textEdit_Conversation->setObjectName(QStringLiteral("textEdit_Conversation"));
        textEdit_Conversation->setGeometry(QRect(60, 190, 341, 181));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(180, 170, 81, 16));
        AvailableFilesListWidget = new QListWidget(centralWidget);
        AvailableFilesListWidget->setObjectName(QStringLiteral("AvailableFilesListWidget"));
        AvailableFilesListWidget->setGeometry(QRect(440, 220, 256, 231));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(510, 190, 91, 16));
        pbDownload = new QPushButton(centralWidget);
        pbDownload->setObjectName(QStringLiteral("pbDownload"));
        pbDownload->setGeometry(QRect(510, 470, 93, 28));
        lineEdit_ClientPort = new QLineEdit(centralWidget);
        lineEdit_ClientPort->setObjectName(QStringLiteral("lineEdit_ClientPort"));
        lineEdit_ClientPort->setGeometry(QRect(420, 70, 71, 22));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(40, 70, 55, 16));
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(330, 70, 81, 16));
        lineEdit_ClientIP = new QLineEdit(centralWidget);
        lineEdit_ClientIP->setObjectName(QStringLiteral("lineEdit_ClientIP"));
        lineEdit_ClientIP->setGeometry(QRect(120, 70, 181, 22));
        pbDisConnect = new QPushButton(centralWidget);
        pbDisConnect->setObjectName(QStringLiteral("pbDisConnect"));
        pbDisConnect->setGeometry(QRect(540, 70, 81, 28));
        textEdit_Status = new QTextEdit(centralWidget);
        textEdit_Status->setObjectName(QStringLiteral("textEdit_Status"));
        textEdit_Status->setGeometry(QRect(60, 400, 341, 101));
        label_8 = new QLabel(centralWidget);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(60, 380, 81, 16));
        Client->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(Client);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 745, 26));
        Client->setMenuBar(menuBar);
        mainToolBar = new QToolBar(Client);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        Client->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(Client);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        Client->setStatusBar(statusBar);

        retranslateUi(Client);

        QMetaObject::connectSlotsByName(Client);
    } // setupUi

    void retranslateUi(QMainWindow *Client)
    {
        Client->setWindowTitle(QApplication::translate("Client", "Client", 0));
        label->setText(QApplication::translate("Client", "Server IP", 0));
        label_2->setText(QApplication::translate("Client", "Server Port", 0));
        lineEdit_ServerIP->setText(QApplication::translate("Client", "192.168.43.111", 0));
        lineEdit_ServerPort->setText(QApplication::translate("Client", "5555", 0));
        pbConnect->setText(QApplication::translate("Client", "Connect", 0));
        label_3->setText(QApplication::translate("Client", "Message", 0));
        lineEdit_Mssage->setText(QApplication::translate("Client", "Hello Server, nice day !", 0));
        pbSend->setText(QApplication::translate("Client", "Send", 0));
        label_4->setText(QApplication::translate("Client", "Conversation", 0));
        label_5->setText(QApplication::translate("Client", "Available Files", 0));
        pbDownload->setText(QApplication::translate("Client", "Download", 0));
        lineEdit_ClientPort->setText(QApplication::translate("Client", "9876", 0));
        label_6->setText(QApplication::translate("Client", "Client IP", 0));
        label_7->setText(QApplication::translate("Client", "Client Port", 0));
        lineEdit_ClientIP->setText(QApplication::translate("Client", "192.168.43.136", 0));
        pbDisConnect->setText(QApplication::translate("Client", "DisConnect", 0));
        label_8->setText(QApplication::translate("Client", "Status", 0));
    } // retranslateUi

};

namespace Ui {
    class Client: public Ui_Client {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENT_H
