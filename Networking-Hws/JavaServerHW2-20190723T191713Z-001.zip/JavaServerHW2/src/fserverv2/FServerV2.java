/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fserverv2;

import java.net.UnknownHostException;

/**
 *
 * @author ShutDowner007
 */
public class FServerV2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws UnknownHostException {
        // TODO code application logic here
        ServerGUI s = new ServerGUI();
        s.setVisible(true);
    }
    
}
