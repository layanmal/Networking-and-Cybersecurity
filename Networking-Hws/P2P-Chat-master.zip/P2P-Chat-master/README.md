# P2P Chat
A chat application b/w Server and Client made using Java Sockets.
<br>
<br>
<br>
To use compile and run the two .java files present in /src folder.
<br>
<br>
Please run the Server app earlier than the Client app.
<br>