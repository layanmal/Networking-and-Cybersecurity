#ifndef ABC_H
#define ABC_H
//#include "client.h"


#include <QObject>

class abc
{
public:
    abc();
//    Client * x;

};

#endif // ABC_H
