#ifndef MYTHREAD_H
#define MYTHREAD_H
#include <QtCore>
//#include "client.h"

class Timer : public QThread
{
    Q_OBJECT
public:
    explicit Timer(QObject * parent = 0 );
    void run();

signals:
    void timeout();

public slots:


};

#endif
