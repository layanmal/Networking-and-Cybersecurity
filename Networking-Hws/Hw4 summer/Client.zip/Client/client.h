#ifndef CLIENT_H
#define CLIENT_H

#include <QWidget>
#include <QtCore>
#include <QList>
#include <QtNetwork>
#include <QUdpSocket>
#include <QTcpSocket>
#include <QMessageBox>

#define PACKET_DATA_SIZE 4500
#define WINDOW_SIZE 1

namespace Ui {
class Client;
}


class Client : public QWidget
{
    Q_OBJECT

public:
    explicit Client(QWidget *parent = 0);
    ~Client();


    QList<QHostAddress> interfacesIPs;
    void getInterfaces();

    QUdpSocket * udpSocket;

    QHostAddress serverIP;
    quint16 serverPort;

    QString username;
    QHostAddress peerIP;
    quint16 peerPort;

    bool interfacesIPsQListInitialized;

    bool filesNamesInitialized;
    QStringList filesNames;
    QString fileName;

    bool fileReceiveMode;
    QFile fileRecieved;
    QByteArray fileReceivedQByteArray;

    int fileSizeExpectedToReceived;
    int fileSizeAlreadyReceived;

    quint16 checksum(QByteArray);

    quint16 expectedSequenceNumber;
    int theNumberOfSequenceNumber;

public slots:
    void connected();
    void disconnected();
    void readyRead();


private slots:
    void on_loginPushButton_clicked();

    void on_interfacesComboBox_currentIndexChanged(int index);

    void on_logoutPushButton_clicked();

    void on_availableFilesListWidget_clicked(const QModelIndex &index);

    void on_downloadPushButton_clicked();

private:
    Ui::Client *ui;
    void clear();
};

#endif // CLIENT_H
