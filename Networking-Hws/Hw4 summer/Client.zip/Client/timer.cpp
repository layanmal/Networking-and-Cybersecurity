#include "timer.h"

Timer::Timer(QObject * parent) :
    QThread(parent)
{

}

void Timer::run()
{

    for(int i=0;i<3;i++)
    {
        qDebug()<<"Hello";
        QThread::sleep(1);
    }


    emit timeout();
}
