#include "client.h"
#include "ui_client.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>

Client::Client(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Client)
{

    ui->setupUi(this);

    this->udpSocket = new QUdpSocket();
    connect(this->udpSocket,SIGNAL(connected()),this,SLOT(connected()));
    connect(this->udpSocket,SIGNAL(disconnected()),this,SLOT(disconnected()));
    connect(this->udpSocket,SIGNAL(readyRead()),this,SLOT(readyRead()));

    this->filesNamesInitialized = false;
    this->fileName = "";

    ui->downloadPushButton->setVisible(false);

    this->interfacesIPsQListInitialized=false;
    this->getInterfaces();

    this->fileReceiveMode = false;
    this->fileReceivedQByteArray.clear();

    ui->serverIPLineEdit->setText("127.0.0.1");
    ui->serverPortLineEdit->setText("5555");
    ui->localPortLineEdit->setText("9999");
    ui->usernameLineEdit->setText("");

    this->expectedSequenceNumber=0;
    this->theNumberOfSequenceNumber = WINDOW_SIZE + 1;


}

Client::~Client()
{
    if(this->udpSocket != NULL)
    {
        this->udpSocket->close();
    }

    delete ui;
}

void Client::on_interfacesComboBox_currentIndexChanged(int index)
{

    this->peerIP=QHostAddress::LocalHost;

    if(this->interfacesIPsQListInitialized)
    {
        this->peerIP = this->interfacesIPs.at(index);
    }

    ui->localIPLineEdit->setText(this->peerIP.toString());

}

void Client::on_loginPushButton_clicked()
{


    this->peerIP = QHostAddress(ui->localIPLineEdit->text());
    QString peerPortString = ui->localPortLineEdit->text();
    this->peerPort = peerPortString.toUShort();

    this->serverIP = QHostAddress(ui->serverIPLineEdit->text());
    QString serverPortString = ui->serverPortLineEdit->text();
    this->serverPort = serverPortString.toUShort();

    QString error;
     if(this->udpSocket->bind(this->peerIP,this->peerPort)) {

        emit(connected());

     } else {

         QDebug(&error) << this->udpSocket->error();
         QMessageBox::critical(this,"Error!",error);

     }

}

void Client::connected()
{
    QByteArray bufferSent("SendToMeTheAvailableFiles,");
    this->udpSocket->writeDatagram(bufferSent,this->serverIP,this->serverPort);
}

void Client::on_availableFilesListWidget_clicked(const QModelIndex &index)
{
    if(this->filesNamesInitialized)
    {
        this->fileName = this->filesNames.at(index.row());
        ui->downloadPushButton->setVisible(true);
    }
}

void Client::on_downloadPushButton_clicked()
{
    QByteArray bufferSent("SendToMyTheFile,");
    bufferSent.append(this->fileName);
    this->udpSocket->writeDatagram(bufferSent,this->serverIP,this->serverPort);
}

void Client::readyRead()
{

    QByteArray bufferRecieved;
    bufferRecieved.resize(udpSocket->pendingDatagramSize());

    QHostAddress senderAddress;
    quint16 senderPort;

    udpSocket->readDatagram(bufferRecieved.data(),bufferRecieved.size(),&senderAddress,&senderPort);

    QString bufferRecievedQString = QString(bufferRecieved);
    QStringList bufferRecievedQStringList = bufferRecievedQString.split(',');

    if(bufferRecievedQStringList[0].compare("TheAvailableFiles") == 0) {

        bufferRecievedQStringList.removeFirst();
        this->filesNames = bufferRecievedQStringList;
        this->filesNamesInitialized = true;

        for(int i=0;i<this->filesNames.size();i++) {

            ui->availableFilesListWidget->addItem(bufferRecievedQStringList[i]);
        }


    }
    else if(bufferRecievedQStringList[0].compare("AcceptReceivingAFile") == 0)
    {

        this->fileSizeExpectedToReceived = bufferRecievedQStringList[1].toInt();
        this->fileReceiveMode = true;
        this->fileSizeAlreadyReceived=0;

    }
    else if(this->fileReceiveMode)
    {
        quint16 sequenceNumber = bufferRecieved.at(bufferRecieved.size() - 3);

        quint16 upperHalfOfChecksum = bufferRecieved.at(bufferRecieved.size() - 2);
        quint16 lowerHalfOfChecksum = bufferRecieved.at(bufferRecieved.size() - 1);

        quint16 checksumExpected = (upperHalfOfChecksum << 8) + (lowerHalfOfChecksum & 0x00FF);

        bufferRecieved.remove( (bufferRecieved.size() - 2),2 );

        quint16 checksumActual = this->checksum(bufferRecieved);

        QByteArray ackBuffer;

        if(checksumActual == checksumExpected)
        {
            if(sequenceNumber == this->expectedSequenceNumber)
            {
                qDebug()<<"Recieved Expected Packet#"<<this->expectedSequenceNumber;

                bufferRecieved.remove(bufferRecieved.length() - 1,1);

                this->fileReceivedQByteArray.append(bufferRecieved);
                this->fileSizeAlreadyReceived += bufferRecieved.size();

                ackBuffer.append(QString("ACK,").toUtf8());
                ackBuffer.append(this->expectedSequenceNumber);
                quint16 checksumValue = this->checksum(ackBuffer);

                ackBuffer.append(checksumValue >> 8);
                ackBuffer.append(checksumValue);
                this->udpSocket->writeDatagram(ackBuffer,senderAddress,senderPort);

                this->expectedSequenceNumber = ( this->expectedSequenceNumber + 1 ) % this->theNumberOfSequenceNumber ;

                if(this->fileSizeAlreadyReceived == this->fileSizeExpectedToReceived)
                {
                    this->expectedSequenceNumber = 0;

                    QString text("<FONT COLOR=blue>");
                    text.append("Server: Sent to you " + this->fileName + " file");
                    text.append("</FONT>");

                    ui->chatTextBrowser->append(text);
                    ui->statusLineEdit->setText("Received From IP:" + senderAddress.toString() + ", Port:" + QString::number(senderPort) );

                    this->fileReceiveMode = false;

                    QByteArray bufferSent = QString("FileReceivedCorrectly,").toUtf8();
                    this->udpSocket->writeDatagram(bufferSent,senderAddress,senderPort);
                    bufferSent.clear();


                     QString pathOfSavingFile = (QFileDialog::getSaveFileName(NULL,"Save file",this->fileName));

                     if( !(pathOfSavingFile.compare("") == 0) )
                     {

                        QFile fileRecieved(pathOfSavingFile);

                        if(fileRecieved.open(QIODevice::WriteOnly))
                        {
                            fileRecieved.write(fileReceivedQByteArray);
                            fileRecieved.flush();
                            ui->statusLineEdit->setText("The file was saved !");
                            fileRecieved.close();
                        }

                     }
                     else
                     {
                        ui->statusLineEdit->setText("You rejected the file !!");
                     }




                this->fileReceivedQByteArray.clear();

                }
            }
            else
            {
                qDebug()<<"Recieved Unexpected Packet#"<<sequenceNumber;


                quint16 lastSequenceNumberRecievedInOrder;

                if(this->expectedSequenceNumber == 0)
                {
                    lastSequenceNumberRecievedInOrder = this->theNumberOfSequenceNumber - 1;
                }
                else
                {
                    lastSequenceNumberRecievedInOrder = (this->expectedSequenceNumber - 1) % this->theNumberOfSequenceNumber;
                }

                ackBuffer.append(QString("ACK,").toUtf8());
                ackBuffer.append(lastSequenceNumberRecievedInOrder);
                quint16 checksumValue = this->checksum(ackBuffer);
                ackBuffer.append(checksumValue >> 8);
                ackBuffer.append(checksumValue);
                this->udpSocket->writeDatagram(ackBuffer,senderAddress,senderPort);
            }
        }
        else
        {
            qDebug()<<"Recieved Corrupted Packet \n";
        }

    }

}

void Client::on_logoutPushButton_clicked()
{
    if(this->udpSocket != NULL)
    {
        emit disconnected();
    }

}

void Client::disconnected()
{
        this->expectedSequenceNumber = 0;
        this->udpSocket->close();

        ui->statusLineEdit->setText("");
        ui->availableFilesListWidget->clear();

        this->fileReceiveMode = false;
        this->expectedSequenceNumber = 0;

}

quint16 Client::checksum(QByteArray buffer)
{
    unsigned short *ptr = (unsigned short *) buffer.data();
    unsigned long checksumValue = 0;
    bool isTheBufferHasOddSize = false;


    int length = buffer.size() / 2 ;

    if( buffer.size() % 2 == 1 )
    {
        length += 1;
        isTheBufferHasOddSize = true;
    }


    for(int i=0;i<length;i++)
    {


        if( ( i == length - 1 ) && isTheBufferHasOddSize )
        {
             unsigned short temp = *ptr;
             temp &= 0x00FF;
             checksumValue += temp;
        }
        else
        {
            checksumValue += *ptr;
        }

        if( checksumValue & (1<<16) )
        {
            checksumValue +=1;
            checksumValue &= 0x0000FFFF;
        }

        ptr++;
    }



    return ~checksumValue;



}

void Client ::getInterfaces()
{

    QList<QNetworkInterface> networkInterfaces = QNetworkInterface::allInterfaces();

    bool hasAddressEntry = false;
    QString interfaceName;

    foreach(QNetworkInterface interface,networkInterfaces)
    {

        QList<QNetworkAddressEntry> addressEntry = interface.addressEntries();

        foreach(QNetworkAddressEntry entry,addressEntry)
        {
            if(!hasAddressEntry)
            {
                interfaceName = interface.name();

                hasAddressEntry = true;
                ui->interfacesComboBox->addItem(interfaceName);
            }

            QHostAddress address = entry.ip();

            if( (interfaceName.compare("lo0") == 0 ) ||  (interfaceName.compare("en0") == 0 ) )
            {
                if(address.protocol()==QAbstractSocket::IPv4Protocol)
                {
                    this->interfacesIPs.append(address);

                }
            }
            else
            {
                   this->interfacesIPs.append(address);

            }

        }
            hasAddressEntry = false;

    }


    this->interfacesIPsQListInitialized=true;

}
