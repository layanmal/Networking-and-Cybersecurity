#ifndef X_H
#define X_H

#include "client.h"
#include "abc.h"

class x
{
public:
    x();
};

#endif // X_H
