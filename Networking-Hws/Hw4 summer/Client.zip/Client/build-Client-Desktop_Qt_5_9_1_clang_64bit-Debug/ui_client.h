/********************************************************************************
** Form generated from reading UI file 'client.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENT_H
#define UI_CLIENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Client
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *serverIPLabel;
    QLineEdit *serverIPLineEdit;
    QHBoxLayout *horizontalLayout_3;
    QLabel *serverPortLabel;
    QLineEdit *serverPortLineEdit;
    QFrame *line;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *usernameLabel;
    QLineEdit *usernameLineEdit;
    QPushButton *loginPushButton;
    QPushButton *logoutPushButton;
    QTextBrowser *chatTextBrowser;
    QPushButton *sendPushButton;
    QWidget *layoutWidget2;
    QVBoxLayout *verticalLayout_3;
    QLabel *interfacesLabel;
    QComboBox *interfacesComboBox;
    QWidget *layoutWidget3;
    QVBoxLayout *verticalLayout_4;
    QHBoxLayout *horizontalLayout_4;
    QLabel *localIPLabel;
    QLineEdit *localIPLineEdit;
    QHBoxLayout *horizontalLayout_5;
    QLabel *localPortLabel;
    QLineEdit *localPortLineEdit;
    QWidget *layoutWidget4;
    QVBoxLayout *verticalLayout_6;
    QLabel *availableFilesLabel;
    QListWidget *availableFilesListWidget;
    QWidget *layoutWidget5;
    QHBoxLayout *horizontalLayout_8;
    QLabel *statusLabel;
    QLineEdit *statusLineEdit;
    QWidget *layoutWidget6;
    QHBoxLayout *horizontalLayout_9;
    QPushButton *downloadPushButton;

    void setupUi(QWidget *Client)
    {
        if (Client->objectName().isEmpty())
            Client->setObjectName(QStringLiteral("Client"));
        Client->resize(838, 445);
        layoutWidget = new QWidget(Client);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(390, 40, 235, 58));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        serverIPLabel = new QLabel(layoutWidget);
        serverIPLabel->setObjectName(QStringLiteral("serverIPLabel"));

        horizontalLayout_2->addWidget(serverIPLabel);

        serverIPLineEdit = new QLineEdit(layoutWidget);
        serverIPLineEdit->setObjectName(QStringLiteral("serverIPLineEdit"));

        horizontalLayout_2->addWidget(serverIPLineEdit);


        verticalLayout_2->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        serverPortLabel = new QLabel(layoutWidget);
        serverPortLabel->setObjectName(QStringLiteral("serverPortLabel"));

        horizontalLayout_3->addWidget(serverPortLabel);

        serverPortLineEdit = new QLineEdit(layoutWidget);
        serverPortLineEdit->setObjectName(QStringLiteral("serverPortLineEdit"));

        horizontalLayout_3->addWidget(serverPortLineEdit);


        verticalLayout_2->addLayout(horizontalLayout_3);

        line = new QFrame(Client);
        line->setObjectName(QStringLiteral("line"));
        line->setGeometry(QRect(390, 270, 221, 16));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);
        layoutWidget1 = new QWidget(Client);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(10, 0, 371, 441));
        verticalLayout = new QVBoxLayout(layoutWidget1);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        usernameLabel = new QLabel(layoutWidget1);
        usernameLabel->setObjectName(QStringLiteral("usernameLabel"));

        horizontalLayout->addWidget(usernameLabel);

        usernameLineEdit = new QLineEdit(layoutWidget1);
        usernameLineEdit->setObjectName(QStringLiteral("usernameLineEdit"));

        horizontalLayout->addWidget(usernameLineEdit);

        loginPushButton = new QPushButton(layoutWidget1);
        loginPushButton->setObjectName(QStringLiteral("loginPushButton"));

        horizontalLayout->addWidget(loginPushButton);

        logoutPushButton = new QPushButton(layoutWidget1);
        logoutPushButton->setObjectName(QStringLiteral("logoutPushButton"));

        horizontalLayout->addWidget(logoutPushButton);


        verticalLayout->addLayout(horizontalLayout);

        chatTextBrowser = new QTextBrowser(layoutWidget1);
        chatTextBrowser->setObjectName(QStringLiteral("chatTextBrowser"));

        verticalLayout->addWidget(chatTextBrowser);

        sendPushButton = new QPushButton(layoutWidget1);
        sendPushButton->setObjectName(QStringLiteral("sendPushButton"));

        verticalLayout->addWidget(sendPushButton);

        layoutWidget2 = new QWidget(Client);
        layoutWidget2->setObjectName(QStringLiteral("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(390, 120, 231, 49));
        verticalLayout_3 = new QVBoxLayout(layoutWidget2);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        interfacesLabel = new QLabel(layoutWidget2);
        interfacesLabel->setObjectName(QStringLiteral("interfacesLabel"));

        verticalLayout_3->addWidget(interfacesLabel);

        interfacesComboBox = new QComboBox(layoutWidget2);
        interfacesComboBox->setObjectName(QStringLiteral("interfacesComboBox"));

        verticalLayout_3->addWidget(interfacesComboBox);

        layoutWidget3 = new QWidget(Client);
        layoutWidget3->setObjectName(QStringLiteral("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(390, 200, 231, 58));
        verticalLayout_4 = new QVBoxLayout(layoutWidget3);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        localIPLabel = new QLabel(layoutWidget3);
        localIPLabel->setObjectName(QStringLiteral("localIPLabel"));

        horizontalLayout_4->addWidget(localIPLabel);

        localIPLineEdit = new QLineEdit(layoutWidget3);
        localIPLineEdit->setObjectName(QStringLiteral("localIPLineEdit"));

        horizontalLayout_4->addWidget(localIPLineEdit);


        verticalLayout_4->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        localPortLabel = new QLabel(layoutWidget3);
        localPortLabel->setObjectName(QStringLiteral("localPortLabel"));

        horizontalLayout_5->addWidget(localPortLabel);

        localPortLineEdit = new QLineEdit(layoutWidget3);
        localPortLineEdit->setObjectName(QStringLiteral("localPortLineEdit"));

        horizontalLayout_5->addWidget(localPortLineEdit);


        verticalLayout_4->addLayout(horizontalLayout_5);

        layoutWidget4 = new QWidget(Client);
        layoutWidget4->setObjectName(QStringLiteral("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(640, 40, 181, 331));
        verticalLayout_6 = new QVBoxLayout(layoutWidget4);
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setContentsMargins(11, 11, 11, 11);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        availableFilesLabel = new QLabel(layoutWidget4);
        availableFilesLabel->setObjectName(QStringLiteral("availableFilesLabel"));

        verticalLayout_6->addWidget(availableFilesLabel);

        availableFilesListWidget = new QListWidget(layoutWidget4);
        availableFilesListWidget->setObjectName(QStringLiteral("availableFilesListWidget"));

        verticalLayout_6->addWidget(availableFilesListWidget);

        layoutWidget5 = new QWidget(Client);
        layoutWidget5->setObjectName(QStringLiteral("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(400, 410, 421, 23));
        horizontalLayout_8 = new QHBoxLayout(layoutWidget5);
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_8->setObjectName(QStringLiteral("horizontalLayout_8"));
        horizontalLayout_8->setContentsMargins(0, 0, 0, 0);
        statusLabel = new QLabel(layoutWidget5);
        statusLabel->setObjectName(QStringLiteral("statusLabel"));

        horizontalLayout_8->addWidget(statusLabel);

        statusLineEdit = new QLineEdit(layoutWidget5);
        statusLineEdit->setObjectName(QStringLiteral("statusLineEdit"));

        horizontalLayout_8->addWidget(statusLineEdit);

        layoutWidget6 = new QWidget(Client);
        layoutWidget6->setObjectName(QStringLiteral("layoutWidget6"));
        layoutWidget6->setGeometry(QRect(390, 370, 232, 32));
        horizontalLayout_9 = new QHBoxLayout(layoutWidget6);
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_9->setObjectName(QStringLiteral("horizontalLayout_9"));
        horizontalLayout_9->setContentsMargins(0, 0, 0, 0);
        downloadPushButton = new QPushButton(layoutWidget6);
        downloadPushButton->setObjectName(QStringLiteral("downloadPushButton"));

        horizontalLayout_9->addWidget(downloadPushButton);

#ifndef QT_NO_SHORTCUT
        usernameLabel->setBuddy(usernameLineEdit);
#endif // QT_NO_SHORTCUT

        retranslateUi(Client);

        QMetaObject::connectSlotsByName(Client);
    } // setupUi

    void retranslateUi(QWidget *Client)
    {
        Client->setWindowTitle(QApplication::translate("Client", "Client", Q_NULLPTR));
        serverIPLabel->setText(QApplication::translate("Client", "UDP Server IP:    ", Q_NULLPTR));
        serverPortLabel->setText(QApplication::translate("Client", "UDP Server Port:", Q_NULLPTR));
        usernameLabel->setText(QApplication::translate("Client", "Username:", Q_NULLPTR));
        loginPushButton->setText(QApplication::translate("Client", "Login", Q_NULLPTR));
        logoutPushButton->setText(QApplication::translate("Client", "Logout", Q_NULLPTR));
        sendPushButton->setText(QApplication::translate("Client", "Send", Q_NULLPTR));
        interfacesLabel->setText(QApplication::translate("Client", "Avaliable Interfaces", Q_NULLPTR));
        localIPLabel->setText(QApplication::translate("Client", "Local IP:            ", Q_NULLPTR));
        localPortLabel->setText(QApplication::translate("Client", "Local Port:        ", Q_NULLPTR));
        availableFilesLabel->setText(QApplication::translate("Client", "Available Files:", Q_NULLPTR));
        statusLabel->setText(QApplication::translate("Client", "Status:", Q_NULLPTR));
        downloadPushButton->setText(QApplication::translate("Client", "Download", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Client: public Ui_Client {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENT_H
