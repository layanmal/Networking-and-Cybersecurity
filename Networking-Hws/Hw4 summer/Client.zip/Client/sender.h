#ifndef SENDER_H
#define SENDER_H

#include <QWidget>
#include "client.h"
//#include "ui_client.h"

//namespace Ui {
//class Client;
//class Sender;
//}

class Sender : public QOBJECT
{
    Q_OBJECT
public:
    Sender();
    Client * client;

};

#endif // SENDER_H
