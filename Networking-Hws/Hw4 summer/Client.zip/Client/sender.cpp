#include "sender.h"

Sender::Sender()
{

//   Ui::Client * x = new Client();

}
