#include "server.h"
#include "ui_server.h"
#include <QDebug>

Server::Server(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Server)
{
    ui->setupUi(this);

    this->udpSocket = new QUdpSocket();
    connect(this->udpSocket,SIGNAL(readyRead()),this,SLOT(readyRead()));

    this->timer = new Timer(this);
    connect(this->timer,SIGNAL(timeout()),this,SLOT(timeout()));
    connect(this,SIGNAL(stopTheTimer()),this->timer,SLOT(stopTheTimer()));

    this->sender = new Sender(this);
    connect(this,SIGNAL(sendAllTheWindow()),this->sender,SLOT(sendAllTheWindow()));

    this->sentNotYetAckedSequenceNumbers = QList<int>();
    this->sentNotYetAckedBuffers = QList<QByteArray>();

    this->fileName = "";

    this->base=0;
    this->nextSequenceNumber=0;
    this->theNumberOfSequenceNumber = WINDOW_SIZE + 1;

    this->getInterfaces();

}

Server::~Server()
{
    if(this->udpSocket != NULL)
    {
        this->udpSocket->close();
    }

    delete ui;
}

void Server::on_listeningPushButton_clicked()
{

    this->serverIP = this->interfacesIPs.at(ui->interfacesComboBox->currentIndex());
    QString serverPortString = ui->PortLineEdit->text();
    this->serverPort = serverPortString.toUShort();

    QString error;
    if(this->udpSocket->bind(this->serverIP,this->serverPort)) {

        this->getFilesNames();
        ui->statusLabel->setText("Status: online on address:" + this->serverIP.toString() + " and port:" + serverPortString );

    } else {

        QDebug(&error) << this->udpSocket->error();
        QMessageBox::critical(this,"Error!",error);

    }

}

void Server::getFilesNames() {

    QDir filesDirectory(FILES_DIR_PATH);
    if(filesDirectory.exists()) {

        this->filesNames = filesDirectory.entryList(QDir::Files);
        for(int i=0;i<filesNames.size();i++) {

            ui->onlineUsersListWidget->addItem(filesNames[i]);
        }
    }
}

void Server::readyRead()
{

    QByteArray bufferRecieved;
    bufferRecieved.resize(udpSocket->pendingDatagramSize());

    udpSocket->readDatagram(bufferRecieved.data(),bufferRecieved.size(),&this->peerRemoteIP,&this->peerRemotePort);

    QString bufferRecievedQString = QString(bufferRecieved);
    QStringList bufferRecievedQStringList = bufferRecievedQString.split(',');

    if(bufferRecievedQStringList[0].compare("SendToMeTheAvailableFiles") == 0) {

        QByteArray bufferSent("TheAvailableFiles,");
        for(int i=0;i<this->filesNames.size();i++) {

            bufferSent.append(this->filesNames[i]);
            if(i != this->filesNames.size() - 1) {
                bufferSent.append(",");
            }

        }

        this->udpSocket->writeDatagram(bufferSent,this->peerRemoteIP,this->peerRemotePort);

    }
    else if(bufferRecievedQStringList[0].compare("SendToMyTheFile") == 0) {

        this->fileName = bufferRecievedQStringList[1];
        this->sender->start();

    }
    else if(bufferRecievedQStringList[0].compare("FileReceivedCorrectly") == 0)
    {
        qDebug()<<"Send Done!";
        this->base = 0;
        this->nextSequenceNumber=0;

        QString text("<FONT COLOR=blue>Status: ");
        text.append(this->fileName +" was sent");
        text.append("</FONT>");

        ui->statusLabel->setText(text);

    }
    else if(bufferRecievedQStringList[0].compare("ACK") == 0)
    {
        quint16 sequenceNumber = bufferRecieved.at(4);

        quint16 upperHalfOfChecksum = bufferRecieved.at(5);
        quint16 lowerHalfOfChecksum = bufferRecieved.at(6);

        quint16 checksumExpected = (upperHalfOfChecksum << 8) + (lowerHalfOfChecksum & 0x00FF);

        bufferRecieved.remove(5,2);

        quint16 checksumActual = this->checksum(bufferRecieved);

        if(checksumActual == checksumExpected)
        {
            if(this->sentNotYetAckedSequenceNumbers.contains(sequenceNumber))
            {
                qDebug()<<"Packet #"<<sequenceNumber<<" ACKed\n";

                quint16 theNextBase = (sequenceNumber + 1) % this->theNumberOfSequenceNumber;

                int index = this->sentNotYetAckedSequenceNumbers.indexOf(sequenceNumber);

                for(int i=0;i<=index;i++)
                {
                    this->sentNotYetAckedSequenceNumbers.removeAt(i);
                    this->sentNotYetAckedBuffers.removeAt(i);
                }

                this->base = theNextBase;
                emit(stopTheTimer());

                if(this->base != this->nextSequenceNumber)
                {

                    if(this->timer->isFinished())
                    {
                       qDebug()<<"Timer restart \n";
                       this->timer->start(QThread::HighestPriority);
                    }

                }

            }
            else
            {
                qDebug()<<"Packet #"<<sequenceNumber<<" Already ACKed\n";
            }
        }
        else
        {
            qDebug()<<"Recieved Corrupted Packet \n";
        }
    }

}

Sender::Sender(Server * server)
{
    this->server = server;
}

void Sender::run()
{
    QByteArray bufferSent;
    QByteArray fileQByteArray;

    QFile file(FILES_DIR_PATH + QString("/") + this->server->fileName );

    if(file.open(QIODevice::ReadOnly))
    {

        bufferSent.append("AcceptReceivingAFile,");
        bufferSent.append(QString::number(file.size()).toUtf8());

        this->server->udpSocket->writeDatagram(bufferSent,this->server->peerRemoteIP,this->server->peerRemotePort);

        bufferSent.clear();

        int currentPositionInTheFile=0;
        while(currentPositionInTheFile < file.size())
        {

             if(
               (
               (this->server->nextSequenceNumber >= this->server->base)
               &&
               ( this->server->nextSequenceNumber < this->server->base + WINDOW_SIZE )
               )
              ||
              (
              (this->server->nextSequenceNumber < this->server->base)
              &&
              ( (this->server->base - this->server->nextSequenceNumber) != (this->server->theNumberOfSequenceNumber - WINDOW_SIZE) )
              )
            )

            {

                 file.seek(currentPositionInTheFile);

                 if( (currentPositionInTheFile + PACKET_DATA_SIZE) <= file.size() )
                 {
                     bufferSent.append( file.read(PACKET_DATA_SIZE) );
                     currentPositionInTheFile+=PACKET_DATA_SIZE;
                 }
                 else
                 {
                     bufferSent.append( file.read( file.size() - currentPositionInTheFile) );
                     currentPositionInTheFile += file.size() - currentPositionInTheFile ;

                 }


                 bufferSent.append(this->server->nextSequenceNumber);
                 quint16 checksumValue = this->server->checksum(bufferSent);

                 bufferSent.append(checksumValue >> 8);
                 bufferSent.append(checksumValue);

                 this->server->sentNotYetAckedBuffers.append(bufferSent);
                 this->server->sentNotYetAckedSequenceNumbers.append(this->server->nextSequenceNumber);

                 qDebug()<<"Sending ... Packet"<<this->server->nextSequenceNumber<<"\n";
                 this->server->udpSocket->writeDatagram(this->server->sentNotYetAckedBuffers.last(),this->server->peerRemoteIP,this->server->peerRemotePort);



                 if(this->server->base == this->server->nextSequenceNumber)
                 {
                     this->server->timer->start(QThread::HighestPriority);
                 }

                 this->server->nextSequenceNumber = ( this->server->nextSequenceNumber + 1 ) % this->server->theNumberOfSequenceNumber ;

                 bufferSent.clear();


                }


          }


        file.close();
        fileQByteArray.clear();
        bufferSent.clear();
     }



}

Timer::Timer(Server * server)
{
    this->server = server;
}

void Timer::run()
{
    qDebug()<<"Timer is running \n";
    msleep(3000);
    emit timeout();
}

void Server::timeout()
{
    qDebug()<<"Timeout!!";
    this->timer->start(QThread::HighestPriority);
    emit(sendAllTheWindow());
}

void Sender::sendAllTheWindow()
{

    for(int i=0;i<this->server->sentNotYetAckedBuffers.size();i++)
    {
        qDebug()<<"Resend "<<this->server->sentNotYetAckedSequenceNumbers.at(i);
        this->server->udpSocket->writeDatagram(this->server->sentNotYetAckedBuffers.at(i),this->server->peerRemoteIP,this->server->peerRemotePort);
    }

}

void Timer::stopTheTimer()
{
   if(this->isRunning())
   {
       this->terminate();
       QThread::wait(100);
   }

}

quint16 Server::checksum(QByteArray buffer)
{
    unsigned short *ptr = (unsigned short *) buffer.data();
    unsigned long checksumValue = 0;
    bool isTheBufferHasOddSize = false;


    int length = buffer.size() / 2 ;

    if( buffer.size() % 2 == 1 )
    {
        length += 1;
        isTheBufferHasOddSize = true;
    }


    for(int i=0;i<length;i++)
    {


        if( ( i == length - 1 ) && isTheBufferHasOddSize )
        {
             unsigned short temp = *ptr;
             temp &= 0x00FF;
             checksumValue += temp;
        }
        else
        {
            checksumValue += *ptr;
        }

        if( checksumValue & (1<<16) )
        {
            checksumValue +=1;
            checksumValue &= 0x0000FFFF;
        }

        ptr++;
    }

    return ~checksumValue;

}

void Server::getInterfaces()
{
    QList<QNetworkInterface> networkInterfaces = QNetworkInterface::allInterfaces();

    bool hasAddressEntry = false;
    QString interfaceName;

    foreach(QNetworkInterface interface,networkInterfaces)
    {

        QList<QNetworkAddressEntry> addressEntry = interface.addressEntries();

        foreach(QNetworkAddressEntry entry,addressEntry)
        {
            if(!hasAddressEntry)
            {
                interfaceName = interface.name();

                hasAddressEntry = true;
                ui->interfacesComboBox->addItem(interfaceName);
            }

            QHostAddress address = entry.ip();

            if( (interfaceName.compare("lo0") == 0 ) ||  (interfaceName.compare("en0") == 0 ) )
            {
                if(address.protocol()==QAbstractSocket::IPv4Protocol)
                {
                    this->interfacesIPs.append(address);

                }
            }
            else
            {
                   this->interfacesIPs.append(address);

            }

        }
            hasAddressEntry = false;

    }
}


