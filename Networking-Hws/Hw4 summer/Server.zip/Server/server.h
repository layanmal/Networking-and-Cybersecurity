#ifndef SERVER_H
#define SERVER_H

#include <QtCore>
#include <QWidget>
#include <QList>
#include <QtNetwork>
#include <QTcpServer>
#include <QTcpSocket>
#include <QMessageBox>
#include <QDir>

#define FILES_DIR_PATH "/Users/me/Desktop/(3)/Server/files"
#define PACKET_DATA_SIZE 4500
#define WINDOW_SIZE 1

namespace Ui {
class Server;
}

class Server;

class Timer : public QThread
{
    Q_OBJECT
public:
    Timer(Server *);
    void run();
    Server * server;

public slots:
    void stopTheTimer();

signals:
    void timeout();

};

class Sender:public QThread
{
    Q_OBJECT
public:
    Sender(Server *);
    void run();
    Server * server;

public slots:
    void sendAllTheWindow();
};


class Server : public QWidget
{
    Q_OBJECT

public:
    explicit Server(QWidget *parent = 0);
    ~Server();

    QUdpSocket * udpSocket;

    QHostAddress serverIP;
    quint16 serverPort;

    QHostAddress peerRemoteIP;
    quint16 peerRemotePort;

    QStringList filesNames;
    QString fileName;
    void getFilesNames();

    Timer * timer;
    Sender * sender;

    quint16 base;
    quint16 nextSequenceNumber;
    int theNumberOfSequenceNumber;

    QList<int> sentNotYetAckedSequenceNumbers;
    QList<QByteArray> sentNotYetAckedBuffers;

    quint16 checksum(QByteArray);

    QList<QHostAddress> interfacesIPs;
    void getInterfaces();

public slots:
    void readyRead();
    void timeout();


private slots:
    void on_listeningPushButton_clicked();

signals:
    void stopTheTimer();
    void sendAllTheWindow();

private:
    Ui::Server *ui;


};

#endif // SERVER_H
