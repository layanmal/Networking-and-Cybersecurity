/********************************************************************************
** Form generated from reading UI file 'server.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SERVER_H
#define UI_SERVER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Server
{
public:
    QLabel *statusLabel;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QPushButton *listeningPushButton;
    QLabel *portLabel;
    QLineEdit *PortLineEdit;
    QComboBox *interfacesComboBox;
    QWidget *layoutWidget1;
    QVBoxLayout *verticalLayout_2;
    QLabel *onlineUsersLabel;
    QListWidget *onlineUsersListWidget;

    void setupUi(QWidget *Server)
    {
        if (Server->objectName().isEmpty())
            Server->setObjectName(QStringLiteral("Server"));
        Server->resize(530, 328);
        statusLabel = new QLabel(Server);
        statusLabel->setObjectName(QStringLiteral("statusLabel"));
        statusLabel->setGeometry(QRect(10, 300, 391, 16));
        layoutWidget = new QWidget(Server);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 110, 271, 68));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        listeningPushButton = new QPushButton(layoutWidget);
        listeningPushButton->setObjectName(QStringLiteral("listeningPushButton"));

        horizontalLayout->addWidget(listeningPushButton);

        portLabel = new QLabel(layoutWidget);
        portLabel->setObjectName(QStringLiteral("portLabel"));

        horizontalLayout->addWidget(portLabel);

        PortLineEdit = new QLineEdit(layoutWidget);
        PortLineEdit->setObjectName(QStringLiteral("PortLineEdit"));

        horizontalLayout->addWidget(PortLineEdit);


        verticalLayout->addLayout(horizontalLayout);

        interfacesComboBox = new QComboBox(layoutWidget);
        interfacesComboBox->setObjectName(QStringLiteral("interfacesComboBox"));

        verticalLayout->addWidget(interfacesComboBox);

        layoutWidget1 = new QWidget(Server);
        layoutWidget1->setObjectName(QStringLiteral("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(290, 10, 231, 281));
        verticalLayout_2 = new QVBoxLayout(layoutWidget1);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        onlineUsersLabel = new QLabel(layoutWidget1);
        onlineUsersLabel->setObjectName(QStringLiteral("onlineUsersLabel"));

        verticalLayout_2->addWidget(onlineUsersLabel);

        onlineUsersListWidget = new QListWidget(layoutWidget1);
        onlineUsersListWidget->setObjectName(QStringLiteral("onlineUsersListWidget"));

        verticalLayout_2->addWidget(onlineUsersListWidget);

#ifndef QT_NO_SHORTCUT
        portLabel->setBuddy(PortLineEdit);
#endif // QT_NO_SHORTCUT

        retranslateUi(Server);

        QMetaObject::connectSlotsByName(Server);
    } // setupUi

    void retranslateUi(QWidget *Server)
    {
        Server->setWindowTitle(QApplication::translate("Server", "Server", Q_NULLPTR));
        statusLabel->setText(QApplication::translate("Server", "Status: offline", Q_NULLPTR));
        listeningPushButton->setText(QApplication::translate("Server", "Start Listening", Q_NULLPTR));
        portLabel->setText(QApplication::translate("Server", "Port:", Q_NULLPTR));
        onlineUsersLabel->setText(QApplication::translate("Server", "Available Files:", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Server: public Ui_Server {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SERVER_H
